package cn.little.red.dao;


import cn.little.red.domain.User;

public interface UserDao {
    /**
     * Query user information based on user name
     * @param username
     * @return
     */
    public User findByUsername(String username);

    /**
     * save user
     * @param user
     */
    public void save(User user);

    User findByCode(String code);


    User findByUsernameAndPassword(String username, String password);
}


