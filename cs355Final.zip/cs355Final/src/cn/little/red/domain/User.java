package cn.little.red.domain;

import java.io.Serializable;

public class User implements Serializable {
    private int uid;//user id
    private String username;
    private String password;
    private String email;
    private String status;//Active state, Y means active, N means inactive
    private String code;//active code

    /**
     * 无参构造方法
     */
    public User() {
    }

    /**
     * 有参构方法
     * @param uid
     * @param username
     * @param password
     * @param email
     * @param status
     * @param code
     */
    public User(int uid, String username, String password, String email, String status, String code) {
        this.uid = uid;
        this.username = username;
        this.password = password;

        this.email = email;

        this.code = code;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
