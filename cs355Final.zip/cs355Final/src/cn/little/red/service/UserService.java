package cn.little.red.service;


import cn.little.red.domain.User;

public interface UserService {
    /**
     * @param user
     * @return
     */
    boolean regist(User user);



    User login(User user);
}
