package cn.little.red.service.impl;


import cn.little.red.dao.UserDao;
import cn.little.red.dao.impl.UserDaoImpl;
import cn.little.red.domain.User;
import cn.little.red.service.UserService;

public class UserServiceImpl implements UserService {

    private UserDao userDao = new UserDaoImpl();
    /**
     * register
     * @param user
     * @return
     */
    @Override
    public boolean regist(User user) {
        //1.Query user object based on user name
        User u = userDao.findByUsername(user.getUsername());
        //if null or not
        if(u != null){
            //Username exists, registration failed
            return false;
        }
        userDao.save(user);
        //2.Save user information
       /* //2.1Set activation code, unique string
        user.setCode(UuidUtil.getUuid());
        //2.2Set activation status
        user.setStatus("N");
        userDao.save(user);

        //3.Activate email sending, email body?

        String content="<a href='http://localhost/travel/user/active?code="+user.getCode()+"'>Click to activate</a>";

        //MailUtils.sendMail(user.getEmail(),content,"Activate Email");
*/
        return true;
    }

    /**
     * Activate user
     * @param code
     * @return
     */
  /*  @Override
    public boolean active(String code) {
        //1.Query user object according to activation code
        User user = userDao.findByCode(code);
        if(user != null){
            //2.Call dao to modify the activation state method
            return true;
        }else{
            return false;
        }



    }
*/
    /**
     * @param user
     * @return
     */
    @Override
    public User login(User user) {
        return userDao.findByUsernameAndPassword(user.getUsername(),user.getPassword());
    }

}
